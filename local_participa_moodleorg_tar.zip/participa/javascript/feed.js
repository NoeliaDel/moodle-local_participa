// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

document.addEventListener('click', function(event) {
    var button = event.target.closest('.local-participa-emoji');
    if (!button) {
        return;
    }

    var form = button.closest('form');
    var target = form ? form.querySelector('[data-participa-emoji-target]') : null;
    if (!target) {
        return;
    }

    var emoji = button.getAttribute('data-emoji') || '';
    var start = target.selectionStart || target.value.length;
    var end = target.selectionEnd || target.value.length;
    var before = target.value.substring(0, start);
    var after = target.value.substring(end);
    var needsSpace = before !== '' && !/\s$/.test(before);
    var insertion = (needsSpace ? ' ' : '') + emoji + ' ';

    target.value = before + insertion + after;
    target.focus();
    target.selectionStart = target.selectionEnd = before.length + insertion.length;
});
