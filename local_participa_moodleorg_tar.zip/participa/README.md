# Participa (`local_participa`)

Participa is a Moodle local plugin that adds a social wall to each course. It gives students a lightweight space to share progress, questions and ideas, react with a visual heart counter, and comment on classmates' posts.

Short description for the Moodle plugins directory:

> A course social wall for student posts, emoji reactions and comments.

## Features

- Course-level feed.
- Students and teachers can publish short posts.
- Optional image URL per post.
- One visual heart reaction per user per post.
- Emoji shortcut bar for posts and comments.
- Threaded-looking comments under each post.
- Floating course shortcut so students can find the wall from course pages and activities.
- Teachers and managers can moderate by deleting posts or comments.

## Requirements

- Moodle 4.5 or later.
- No third-party services.
- No additional Moodle plugin dependencies.

## Installation

1. Copy `local/participa` into the Moodle installation under `local/participa`.
2. Visit `Site administration > Notifications` as an administrator so Moodle creates the plugin tables.
3. Open any course and use the `Participa wall` navigation item.

## ZIP package

For the Moodle plugins directory, the ZIP package must contain a single top-level `participa` folder. In this workspace, create it with:

```powershell
Compress-Archive -Path local\participa -DestinationPath local_participa.zip -Force
```

## Privacy

The plugin stores course posts, comments and heart reactions in Moodle database tables. It does not send data to external services.

## License

GNU GPL v3 or later.
