<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

$string['pluginname'] = 'Participa';
$string['feed'] = 'Muro Participa';
$string['feedintro'] = 'Comparte avances, preguntas e ideas con tu clase.';
$string['participa:view'] = 'Ver el muro Participa';
$string['participa:post'] = 'Publicar en el muro Participa';
$string['participa:comment'] = 'Comentar en el muro Participa';
$string['participa:react'] = 'Reaccionar con corazones en el muro Participa';
$string['participa:manage'] = 'Moderar el muro Participa';
$string['privacy:metadata'] = 'Participa guarda publicaciones, comentarios y reacciones creadas por usuarios dentro de cursos Moodle.';
$string['privacy:metadata:posts'] = 'Publicaciones del muro Participa.';
$string['privacy:metadata:comments'] = 'Comentarios en publicaciones del muro Participa.';
$string['privacy:metadata:reactions'] = 'Reacciones en publicaciones del muro Participa.';
$string['privacy:metadata:courseid'] = 'ID del curso donde ocurre la participacion.';
$string['privacy:metadata:userid'] = 'ID del usuario que creo el contenido o reaccion.';
$string['privacy:metadata:postid'] = 'ID de la publicacion relacionada.';
$string['privacy:metadata:content'] = 'Texto creado por el usuario.';
$string['privacy:metadata:imageurl'] = 'URL opcional de imagen compartida por el usuario.';
$string['privacy:metadata:timecreated'] = 'Fecha de creacion.';
$string['privacy:metadata:timemodified'] = 'Fecha de ultima modificacion.';
$string['newpost'] = 'Nueva publicacion';
$string['postplaceholder'] = 'Comparte una idea, avance, duda o logro con la clase...';
$string['imageurl'] = 'URL de imagen opcional';
$string['publish'] = 'Publicar';
$string['commentplaceholder'] = 'Escribe un comentario...';
$string['comment'] = 'Comentar';
$string['react'] = 'Reaccionar';
$string['unreact'] = 'Quitar reaccion';
$string['emojis'] = 'Emojis';
$string['addemoji'] = 'Agregar emoji {$a}';
$string['openwall'] = 'Abrir Participa';
$string['delete'] = 'Eliminar';
$string['noposts'] = 'Todavia no hay publicaciones. Puedes iniciar la conversacion.';
$string['emptycontent'] = 'Escribe algun contenido antes de publicar.';
$string['invalidpost'] = 'La publicacion no existe o no pertenece a este curso.';
