<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

$string['pluginname'] = 'Participa';
$string['feed'] = 'Participa wall';
$string['feedintro'] = 'Share progress, questions and ideas with your class.';
$string['participa:view'] = 'View the Participa wall';
$string['participa:post'] = 'Post on the Participa wall';
$string['participa:comment'] = 'Comment on the Participa wall';
$string['participa:react'] = 'React with hearts on the Participa wall';
$string['participa:manage'] = 'Moderate the Participa wall';
$string['privacy:metadata'] = 'Participa stores posts, comments and reactions created by users inside Moodle courses.';
$string['privacy:metadata:posts'] = 'Participa wall posts.';
$string['privacy:metadata:comments'] = 'Comments on Participa wall posts.';
$string['privacy:metadata:reactions'] = 'Heart reactions on Participa wall posts.';
$string['privacy:metadata:courseid'] = 'Course ID where participation happens.';
$string['privacy:metadata:userid'] = 'User ID of the author or reacting user.';
$string['privacy:metadata:postid'] = 'Related post ID.';
$string['privacy:metadata:content'] = 'User-created text.';
$string['privacy:metadata:imageurl'] = 'Optional image URL shared by the user.';
$string['privacy:metadata:timecreated'] = 'Creation time.';
$string['privacy:metadata:timemodified'] = 'Last modification time.';
$string['newpost'] = 'New post';
$string['postplaceholder'] = 'Share an idea, progress update, question or achievement with the class...';
$string['imageurl'] = 'Optional image URL';
$string['publish'] = 'Publish';
$string['commentplaceholder'] = 'Write a comment...';
$string['comment'] = 'Comment';
$string['heart'] = 'Heart';
$string['unheart'] = 'Remove heart';
$string['react'] = 'React';
$string['unreact'] = 'Remove reaction';
$string['emojis'] = 'Emojis';
$string['addemoji'] = 'Add emoji {$a}';
$string['openwall'] = 'Open Participa';
$string['delete'] = 'Delete';
$string['noposts'] = 'There are no posts yet. You can start the conversation.';
$string['emptycontent'] = 'Write some content before posting.';
$string['invalidpost'] = 'The post does not exist or does not belong to this course.';
