<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

defined('MOODLE_INTERNAL') || die();

function local_participa_extend_navigation_course(navigation_node $navigation, stdClass $course, context_course $context): void {
    if (!has_capability('local/participa:view', $context)) {
        return;
    }

    $url = new moodle_url('/local/participa/index.php', ['courseid' => $course->id]);
    $node = $navigation->add(
        get_string('feed', 'local_participa'),
        $url,
        navigation_node::TYPE_CUSTOM,
        null,
        'local_participa'
    );
    $node->showinflatnavigation = true;
}

function local_participa_before_standard_html_head(): string {
    global $COURSE, $PAGE;

    if (empty($COURSE->id) || (int)$COURSE->id === SITEID) {
        return '';
    }

    if ($PAGE->pagetype === 'local-participa-index') {
        return '';
    }

    $context = context_course::instance($COURSE->id, IGNORE_MISSING);
    if (!$context || !has_capability('local/participa:view', $context)) {
        return '';
    }

    $PAGE->requires->css('/local/participa/styles/feed.css');

    return '';
}

function local_participa_before_footer(): string {
    global $COURSE, $PAGE;

    if (empty($COURSE->id) || (int)$COURSE->id === SITEID) {
        return '';
    }

    if ($PAGE->pagetype === 'local-participa-index') {
        return '';
    }

    $context = context_course::instance($COURSE->id, IGNORE_MISSING);
    if (!$context || !has_capability('local/participa:view', $context)) {
        return '';
    }

    $url = new moodle_url('/local/participa/index.php', ['courseid' => $COURSE->id]);

    return html_writer::link(
        $url,
        html_writer::span('&#9829;', 'local-participa-floating-icon', ['aria-hidden' => 'true']) .
            html_writer::span(get_string('openwall', 'local_participa'), 'local-participa-floating-text'),
        [
            'class' => 'local-participa-floating-link',
            'aria-label' => get_string('openwall', 'local_participa'),
        ]
    );
}
