# Changelog

## 0.1.0 - 2026-05-12

- Initial alpha release.
- Added course social wall.
- Added post composer with optional image URL.
- Added visual heart reactions with one reaction per user and post.
- Added comments.
- Added emoji shortcuts for posts and comments.
- Added a floating course shortcut to make the wall easier for students to find.
- Added moderation actions for teachers and managers.
