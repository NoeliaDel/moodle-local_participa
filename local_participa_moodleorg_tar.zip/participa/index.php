<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

require_once(__DIR__ . '/../../config.php');

$courseid = required_param('courseid', PARAM_INT);
$action = optional_param('action', '', PARAM_ALPHA);
$postid = optional_param('postid', 0, PARAM_INT);
$commentid = optional_param('commentid', 0, PARAM_INT);

$course = get_course($courseid);
require_login($course);

$context = context_course::instance($course->id);
require_capability('local/participa:view', $context);

$url = new moodle_url('/local/participa/index.php', ['courseid' => $course->id]);
$PAGE->set_url($url);
$PAGE->set_context($context);
$PAGE->set_course($course);
$PAGE->set_title(get_string('feed', 'local_participa'));
$PAGE->set_heading($course->fullname);
$PAGE->requires->css('/local/participa/styles/feed.css');
$PAGE->requires->js('/local/participa/javascript/feed.js');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_sesskey();

    if ($action === 'addpost') {
        require_capability('local/participa:post', $context);

        $content = trim(required_param('content', PARAM_TEXT));
        $imageurl = trim(optional_param('imageurl', '', PARAM_URL));

        if ($content === '') {
            redirect($url, get_string('emptycontent', 'local_participa'), null, \core\output\notification::NOTIFY_WARNING);
        }

        $now = time();
        $record = (object)[
            'courseid' => $course->id,
            'userid' => $USER->id,
            'content' => $content,
            'imageurl' => $imageurl,
            'visible' => 1,
            'timecreated' => $now,
            'timemodified' => $now,
        ];
        $DB->insert_record('local_participa_posts', $record);
        redirect($url);
    }

    if ($action === 'addcomment') {
        require_capability('local/participa:comment', $context);
        $post = local_participa_get_post($postid, $course->id);

        $content = trim(required_param('content', PARAM_TEXT));
        if ($content !== '') {
            $now = time();
            $DB->insert_record('local_participa_comments', (object)[
                'postid' => $post->id,
                'userid' => $USER->id,
                'content' => $content,
                'timecreated' => $now,
                'timemodified' => $now,
            ]);
        }
        redirect($url);
    }

    if ($action === 'toggleheart') {
        require_capability('local/participa:react', $context);
        $post = local_participa_get_post($postid, $course->id);

        $params = ['postid' => $post->id, 'userid' => $USER->id];
        if ($reaction = $DB->get_record('local_participa_reactions', $params)) {
            $DB->delete_records('local_participa_reactions', ['id' => $reaction->id]);
        } else {
            $DB->insert_record('local_participa_reactions', (object)[
                'postid' => $post->id,
                'userid' => $USER->id,
                'timecreated' => time(),
            ]);
        }
        redirect($url);
    }

    if ($action === 'deletepost') {
        require_capability('local/participa:manage', $context);
        $post = local_participa_get_post($postid, $course->id);
        $DB->delete_records('local_participa_reactions', ['postid' => $post->id]);
        $DB->delete_records('local_participa_comments', ['postid' => $post->id]);
        $DB->delete_records('local_participa_posts', ['id' => $post->id]);
        redirect($url);
    }

    if ($action === 'deletecomment') {
        require_capability('local/participa:manage', $context);
        $comment = $DB->get_record('local_participa_comments', ['id' => $commentid], '*', MUST_EXIST);
        local_participa_get_post((int)$comment->postid, $course->id);
        $DB->delete_records('local_participa_comments', ['id' => $comment->id]);
        redirect($url);
    }
}

echo $OUTPUT->header();
echo html_writer::start_div('local-participa');
echo html_writer::start_div('local-participa-hero');
echo html_writer::tag('h2', get_string('feed', 'local_participa'));
echo html_writer::div(get_string('feedintro', 'local_participa'), 'local-participa-hero-text');
echo html_writer::end_div();

if (has_capability('local/participa:post', $context)) {
    echo html_writer::start_tag('form', ['method' => 'post', 'class' => 'local-participa-composer']);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'addpost']);
    echo html_writer::tag('h3', get_string('newpost', 'local_participa'));
    echo html_writer::start_div('local-participa-field');
    echo html_writer::tag('textarea', '', [
        'name' => 'content',
        'maxlength' => 2000,
        'placeholder' => get_string('postplaceholder', 'local_participa'),
        'required' => 'required',
        'data-participa-emoji-target' => '1',
    ]);
    echo local_participa_emoji_picker();
    echo html_writer::end_div();
    echo html_writer::start_div('local-participa-field');
    echo html_writer::empty_tag('input', [
        'type' => 'url',
        'name' => 'imageurl',
        'placeholder' => get_string('imageurl', 'local_participa'),
    ]);
    echo html_writer::end_div();
    echo html_writer::tag('button', get_string('publish', 'local_participa'), ['type' => 'submit', 'class' => 'btn btn-primary']);
    echo html_writer::end_tag('form');
}

$posts = local_participa_get_posts($course->id, $USER->id);
if (!$posts) {
    echo html_writer::div(get_string('noposts', 'local_participa'), 'alert alert-info');
}

foreach ($posts as $post) {
    echo local_participa_render_post($post, $course, $context, $url);
}

echo html_writer::end_div();
echo $OUTPUT->footer();

function local_participa_get_post(int $postid, int $courseid): stdClass {
    global $DB;

    $post = $DB->get_record('local_participa_posts', ['id' => $postid, 'courseid' => $courseid, 'visible' => 1]);
    if (!$post) {
        throw new moodle_exception('invalidpost', 'local_participa');
    }

    return $post;
}

function local_participa_get_posts(int $courseid, int $userid): array {
    global $DB;

    $sql = "SELECT p.*,
                   u.firstname,
                   u.lastname,
                   u.firstnamephonetic,
                   u.lastnamephonetic,
                   u.middlename,
                   u.alternatename,
                   u.imagealt,
                   u.picture,
                   u.email,
                   COUNT(DISTINCT r.id) AS heartcount,
                   MAX(CASE WHEN mine.id IS NULL THEN 0 ELSE 1 END) AS hashearted
              FROM {local_participa_posts} p
              JOIN {user} u ON u.id = p.userid
         LEFT JOIN {local_participa_reactions} r ON r.postid = p.id
         LEFT JOIN {local_participa_reactions} mine ON mine.postid = p.id AND mine.userid = :userid
             WHERE p.courseid = :courseid
               AND p.visible = 1
          GROUP BY p.id, p.courseid, p.userid, p.content, p.imageurl, p.visible, p.timecreated, p.timemodified,
                   u.firstname, u.lastname, u.firstnamephonetic, u.lastnamephonetic, u.middlename, u.alternatename,
                   u.imagealt, u.picture, u.email
          ORDER BY p.timecreated DESC";

    return $DB->get_records_sql($sql, ['courseid' => $courseid, 'userid' => $userid]);
}

function local_participa_render_post(stdClass $post, stdClass $course, context_course $context, moodle_url $pageurl): string {
    global $DB, $OUTPUT, $USER;

    $author = (object)[
        'id' => $post->userid,
        'firstname' => $post->firstname,
        'lastname' => $post->lastname,
        'firstnamephonetic' => $post->firstnamephonetic,
        'lastnamephonetic' => $post->lastnamephonetic,
        'middlename' => $post->middlename,
        'alternatename' => $post->alternatename,
        'imagealt' => $post->imagealt,
        'picture' => $post->picture,
        'email' => $post->email,
    ];

    $out = html_writer::start_div('local-participa-post');
    $out .= html_writer::start_div('local-participa-post-header');
    $out .= $OUTPUT->user_picture($author, ['courseid' => $course->id, 'size' => 48]);
    $out .= html_writer::start_div();
    $out .= html_writer::div(fullname($author), 'local-participa-author');
    $out .= html_writer::div(userdate($post->timecreated), 'local-participa-time');
    $out .= html_writer::end_div();
    $out .= html_writer::end_div();

    $out .= html_writer::start_div('local-participa-post-body');
    $out .= html_writer::div(format_text($post->content, FORMAT_PLAIN, ['context' => $context]), 'local-participa-content');
    $imageurl = trim((string)$post->imageurl);
    if ($imageurl !== '') {
        $out .= html_writer::empty_tag('img', [
            'src' => $imageurl,
            'alt' => '',
            'class' => 'local-participa-image',
            'loading' => 'lazy',
        ]);
    }
    $out .= html_writer::end_div();

    $out .= html_writer::start_div('local-participa-post-actions');
    if (has_capability('local/participa:react', $context)) {
        $out .= html_writer::start_tag('form', ['method' => 'post']);
        $out .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
        $out .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'toggleheart']);
        $out .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'postid', 'value' => $post->id]);
        $label = ((int)$post->hashearted === 1) ? get_string('unreact', 'local_participa') : get_string('react', 'local_participa');
        $class = ((int)$post->hashearted === 1) ? 'local-participa-heart is-active' : 'local-participa-heart';
        $out .= html_writer::tag('button', '<span aria-hidden="true">&#9829;</span><span>' . (int)$post->heartcount . '</span>', [
            'type' => 'submit',
            'class' => $class,
            'aria-label' => $label,
        ]);
        $out .= html_writer::end_tag('form');
    } else {
        $out .= html_writer::span('&#9829; ' . (int)$post->heartcount, 'local-participa-heart');
    }
    if (has_capability('local/participa:manage', $context)) {
        $out .= local_participa_delete_form('deletepost', (int)$post->id, 0);
    }
    $out .= html_writer::end_div();

    $comments = $DB->get_records_sql(
        "SELECT c.*, u.firstname, u.lastname, u.firstnamephonetic, u.lastnamephonetic, u.middlename,
                u.alternatename, u.imagealt, u.picture, u.email
           FROM {local_participa_comments} c
           JOIN {user} u ON u.id = c.userid
          WHERE c.postid = :postid
       ORDER BY c.timecreated ASC",
        ['postid' => $post->id]
    );

    $out .= html_writer::start_div('local-participa-comments');
    foreach ($comments as $comment) {
        $commentauthor = (object)[
            'id' => $comment->userid,
            'firstname' => $comment->firstname,
            'lastname' => $comment->lastname,
            'firstnamephonetic' => $comment->firstnamephonetic,
            'lastnamephonetic' => $comment->lastnamephonetic,
            'middlename' => $comment->middlename,
            'alternatename' => $comment->alternatename,
            'imagealt' => $comment->imagealt,
            'picture' => $comment->picture,
            'email' => $comment->email,
        ];
        $out .= html_writer::start_div('local-participa-comment');
        $out .= html_writer::span(fullname($commentauthor), 'local-participa-comment-author') . ' ';
        $out .= html_writer::span(format_text($comment->content, FORMAT_PLAIN, ['context' => $context]));
        if (has_capability('local/participa:manage', $context)) {
            $out .= ' ' . local_participa_delete_form('deletecomment', 0, (int)$comment->id);
        }
        $out .= html_writer::end_div();
    }

    if (has_capability('local/participa:comment', $context)) {
        $out .= html_writer::start_tag('form', ['method' => 'post', 'class' => 'local-participa-comment-form']);
        $out .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
        $out .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'addcomment']);
        $out .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'postid', 'value' => $post->id]);
        $out .= html_writer::empty_tag('input', [
            'type' => 'text',
            'name' => 'content',
            'maxlength' => 1000,
            'placeholder' => get_string('commentplaceholder', 'local_participa'),
            'required' => 'required',
            'data-participa-emoji-target' => '1',
        ]);
        $out .= local_participa_emoji_picker();
        $out .= html_writer::tag('button', get_string('comment', 'local_participa'), ['type' => 'submit', 'class' => 'btn btn-secondary']);
        $out .= html_writer::end_tag('form');
    }
    $out .= html_writer::end_div();
    $out .= html_writer::end_div();

    return $out;
}

function local_participa_delete_form(string $action, int $postid, int $commentid): string {
    $out = html_writer::start_tag('form', ['method' => 'post']);
    $out .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
    $out .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => $action]);
    if ($postid > 0) {
        $out .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'postid', 'value' => $postid]);
    }
    if ($commentid > 0) {
        $out .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'commentid', 'value' => $commentid]);
    }
    $out .= html_writer::tag('button', get_string('delete', 'local_participa'), [
        'type' => 'submit',
        'class' => 'btn btn-link text-danger',
    ]);
    $out .= html_writer::end_tag('form');

    return $out;
}

function local_participa_emoji_picker(): string {
    $emojis = ['😀', '👏', '🔥', '💡', '🙌', '🤔', '⭐', '🎯'];
    $out = html_writer::start_div('local-participa-emoji-bar', ['aria-label' => get_string('emojis', 'local_participa')]);
    foreach ($emojis as $emoji) {
        $out .= html_writer::tag('button', $emoji, [
            'type' => 'button',
            'class' => 'local-participa-emoji',
            'data-emoji' => $emoji,
            'aria-label' => get_string('addemoji', 'local_participa', $emoji),
        ]);
    }
    $out .= html_writer::end_div();

    return $out;
}
