<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

namespace local_participa\privacy;

defined('MOODLE_INTERNAL') || die();

use core_privacy\local\metadata\collection;

class provider implements \core_privacy\local\metadata\provider {
    public static function get_metadata(collection $collection): collection {
        $collection->add_database_table('local_participa_posts', [
            'courseid' => 'privacy:metadata:courseid',
            'userid' => 'privacy:metadata:userid',
            'content' => 'privacy:metadata:content',
            'imageurl' => 'privacy:metadata:imageurl',
            'timecreated' => 'privacy:metadata:timecreated',
            'timemodified' => 'privacy:metadata:timemodified',
        ], 'privacy:metadata:posts');

        $collection->add_database_table('local_participa_comments', [
            'postid' => 'privacy:metadata:postid',
            'userid' => 'privacy:metadata:userid',
            'content' => 'privacy:metadata:content',
            'timecreated' => 'privacy:metadata:timecreated',
            'timemodified' => 'privacy:metadata:timemodified',
        ], 'privacy:metadata:comments');

        $collection->add_database_table('local_participa_reactions', [
            'postid' => 'privacy:metadata:postid',
            'userid' => 'privacy:metadata:userid',
            'timecreated' => 'privacy:metadata:timecreated',
        ], 'privacy:metadata:reactions');

        return $collection;
    }
}
